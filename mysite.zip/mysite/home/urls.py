from django.urls import path,include
from .views import *
# from django.contrib.auth.decorators import login_required

urlpatterns = [
    path('', login, name = 'login'),
    path('home/', index, name = 'home'),
    path('change_password/', password, name = 'change_password'),
    path('register/', register, name = 'register'),
]
