from django.contrib import admin
from .models import *

admin.site.register(Company)
admin.site.register(SalaryExpense)
admin.site.register(AngelInvester)
admin.site.register(InvestmentEquity)
admin.site.register(InvestmentPreference)
admin.site.register(Trade)