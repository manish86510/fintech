from django.shortcuts import render
from .models import *

def login(request):
    if request.method == 'POST':
        login = None
        try:
            login = AngelInvester.objects.get(email=request.POST['email'], password=request.POST['password'])
            request.session['email'] = request.POST['email']
            request.session['role'] = "investor"
            data = Trade.objects.filter(investor=login)
            print(data)
            return render(request, 'index.html', {'message': login, 'data': data})
        except:
            return render(request, 'login.html', {'message': "Not found!"})
    return render(request, 'login.html')

def register(request):
    return render(request, 'register.html')

def password(request):
    return render(request, 'password.html')

def index(request):
    return render(request, 'index.html')