from django.db import models
from django.db.models.deletion import CASCADE


class Company(models.Model):
    name = models.CharField(max_length=2000)
    email = models.CharField(max_length=2000)
    password = models.CharField(max_length=100, null=True)
    logo = models.ImageField(upload_to ='uploads/')
    about = models.TextField()
    pitch_deck = models.FileField(upload_to='uploads/files/')
    business_financial_projection = models.FileField(upload_to='uploads/files/')
    faq_about_business = models.TextField()
    authorised_capital = models.CharField(max_length=2000, null=True)
    id_up_in_equity = models.CharField(max_length=2000, null=True)
    total_paid_up_capital = models.CharField(max_length=2000, null=True)
    paid_up_in_prefrence = models.CharField(max_length=2000, null=True)
    no_of_shareholder = models.CharField(max_length=2000, null=True)
    no_of_employees = models.CharField(max_length=2000, null=True)
    total_contract_employee = models.CharField(max_length=2000, null=True)
    total_office_location = models.CharField(max_length=100, null=True)
    yearly_expense = models.CharField(max_length=2000, null=True)
    monthly_update = models.CharField(max_length=2000, null=True)
    contract_employees_add = models.CharField(max_length=2000, null=True)
    is_verify = models.CharField(max_length=10, null=True)
    is_active = models.CharField(max_length=10, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class SalaryExpense(models.Model):
    company = models.ForeignKey(Company,on_delete=models.CASCADE)
    commission_expense = models.CharField(max_length=2000, null=True)
    third_party_expense = models.CharField(max_length=2000, null=True)
    office_expense = models.CharField(max_length=2000, null=True)
    assets_expense = models.CharField(max_length=2000, null=True)
    marketing_expense = models.CharField(max_length=2000, null=True)
    online_payments = models.CharField(max_length=2000, null=True)
    audit_fees = models.CharField(max_length=2000, null=True)
    consulting_fees = models.CharField(max_length=2000, null=True)
    miscellaneous_payments = models.CharField(max_length=2000, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.commission_expense

class AngelInvester(models.Model):
    name = models.CharField(max_length=2000)
    email = models.CharField(max_length=2000)
    password = models.CharField(max_length=100, null=True)
    myprofile = models.CharField(max_length=2000, null=True)
    banker_name = models.CharField(max_length=2000, null=True)
    banker_number = models.CharField(max_length=2000, null=True)
    dob = models.CharField(max_length=2000, null=True)
    pan = models.CharField(max_length=2000, null=True)
    aadhar = models.CharField(max_length=2000, null=True)
    profile = models.ImageField(upload_to ='uploads/')
    address = models.TextField()
    is_verify = models.CharField(max_length=10, null=True)
    is_active = models.CharField(max_length=10, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class InvestmentEquity(models.Model):
    investor = models.ForeignKey(AngelInvester,on_delete=models.CASCADE)
    company_name = models.CharField(max_length=2000, null=True)
    investment_amount = models.CharField(max_length=2000, null=True)
    shares_hold = models.CharField(max_length=2000, null=True)
    face_value = models.CharField(max_length=2000, null=True)
    divident_received = models.CharField(max_length=2000, null=True)
    request_for_exit = models.CharField(max_length=2000, null=True)
    condition =models.TextField()
    commitment =models.TextField()
    status = models.CharField(max_length=2000, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.company_name

class InvestmentPreference(models.Model):
    investor = models.ForeignKey(AngelInvester,on_delete=models.CASCADE)
    company_name = models.CharField(max_length=2000, null=True)
    investment_amount = models.CharField(max_length=2000, null=True)
    shares_hold = models.CharField(max_length=2000, null=True)
    face_value = models.CharField(max_length=2000, null=True)
    divident_received = models.CharField(max_length=2000, null=True)
    request_for_exit = models.CharField(max_length=2000, null=True)
    condition =models.TextField()
    commitment =models.TextField()
    convertable_nonconvertable = models.CharField(max_length=2000, null=True)
    status = models.CharField(max_length=2000, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.company_name

# class Startups(models.Model):
#     verified_ipos = models.CharField(max_length=2000)
#     startup = models.CharField(max_length=2000, null=True)
#     coming = models.CharField(max_length=2000, null=True)

class Trade(models.Model):
    investor = models.ForeignKey(AngelInvester,on_delete=models.CASCADE, null=True)
    company = models.ForeignKey(Company,on_delete=models.CASCADE, null=True)
    shares = models.CharField(max_length=2000, null=True)
    amount = models.CharField(max_length=2000, null=True)
    trade_type = models.CharField(max_length=2000, null=True)
    status = models.CharField(max_length=2000, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.trade_type

